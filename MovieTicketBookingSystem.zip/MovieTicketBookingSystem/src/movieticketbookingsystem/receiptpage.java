/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package movieticketbookingsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import movieticketbookingsystem.MovieTicketBookingSystem;

/**
 *
 * @author Marcellino
 */
public class receiptpage extends javax.swing.JFrame {
    Connection conn = null;
    
    /**
     * Creates new form receiptpage
     */
    public receiptpage() {
        initComponents();conn = MovieTicketBookingSystem.ConnectDb();
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Failed to connect to the database");
            System.exit(0);
        }
        loadLatestInfo();
    }

        private void loadLatestInfo() {
            try {
                String query = "SELECT t.ticket_id, t.theater_name, t.movie_title, t.amount AS ticket_amount, t.price AS ticket_price,"
                             + "f.size_popcorn, f.quantity_popcorn, f.size_softdrink, f.quantity_softdrink, f.price AS fnb_price "
                             + "FROM ticket t "
                             + "LEFT JOIN fnb f ON t.ticket_id = f.fnb_id "
                             + "ORDER BY t.ticket_id DESC LIMIT 1";

                PreparedStatement pstmt = conn.prepareStatement(query);
                ResultSet rs = pstmt.executeQuery();

                if (rs.next()) {
                    String ticketId = rs.getString("ticket_id");
                    String theaterName = rs.getString("theater_name");
                    String movieTitle = rs.getString("movie_title");
                    String ticketAmount = rs.getString("ticket_amount");

                    // Remove "Rp " prefix and parse ticket price as an integer
                    String ticketPriceText = rs.getString("ticket_price");
                    int ticketPrice = parsePrice(ticketPriceText);

                    String popcornSize = rs.getString("size_popcorn");
                    String popcornQuantity = rs.getString("quantity_popcorn");
                    String softdrinkSize = rs.getString("size_softdrink");
                    String softdrinkQuantity = rs.getString("quantity_softdrink");

                    // Check if Fnb price is available
                    int fnbPrice = 0; // Default to 0 if Fnb price is not available
                    String fnbPriceText = rs.getString("fnb_price");
                    if (fnbPriceText != null) {
                        fnbPrice = parsePrice(fnbPriceText);
                    }

                    jLabelticket.setText(ticketId);
                    jLabeltheater.setText(theaterName);
                    jLabelmovie.setText(movieTitle);
                    jLabelamount.setText(ticketAmount);

                    // Assuming you have jLabels for displaying fnb information as well
                    jLabelPopcornSize.setText(popcornSize != null ? popcornSize : "-");
                    jLabelPopcornQuantity.setText(popcornQuantity != null ? popcornQuantity : "-");
                    jLabelSoftdrinkSize.setText(softdrinkSize != null ? softdrinkSize : "-");
                    jLabelSoftdrinkQuantity.setText(softdrinkQuantity != null ? softdrinkQuantity : "-");

                    // Calculate and display total price (ticket price + fnb price if available)
                    int totalPrice = ticketPrice + fnbPrice;
                    jLabelTotalPrice.setText("Rp" + totalPrice);

                } else {
                    // Handle case when no data is found
                    jLabelticket.setText("-");
                    jLabeltheater.setText("-");
                    jLabelmovie.setText("-");
                    jLabelamount.setText("-");
                    // Set labels for fnb information to "No data" as well
                    jLabelPopcornSize.setText("-");
                    jLabelPopcornQuantity.setText("-");
                    jLabelSoftdrinkSize.setText("-");
                    jLabelSoftdrinkQuantity.setText("-");
                    jLabelTotalPrice.setText("-"); // Set total price label as "No data"
                }

                rs.close();
                pstmt.close();
            } catch (SQLException e) {
                System.out.println(e);
                JOptionPane.showMessageDialog(this, "Error occurred while loading ticket and fnb information");
            }
        }


        // Helper method to parse price string and extract numeric value
        private int parsePrice(String priceText) {
            if (priceText != null && priceText.startsWith("Rp")) {
                String numericValue = priceText.substring(2); // Skip "Rp " prefix
                try {
                    return Integer.parseInt(numericValue);
                } catch (NumberFormatException e) {
                    // Handle parsing error
                    System.out.println("Error parsing price: " + e.getMessage());
                }
            }
            return 0; // Default value if parsing fails
        }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabelSoftdrinkSize = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabelTotalPrice = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabelmovie = new javax.swing.JLabel();
        jLabelamount = new javax.swing.JLabel();
        jLabelticket = new javax.swing.JLabel();
        jLabeltheater = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabelPopcornQuantity = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabelPopcornSize = new javax.swing.JLabel();
        jLabelSoftdrinkQuantity = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setText("Movie Ticket Booking System");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Receipt");

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel12.setText("Soft Drink");

        jLabelSoftdrinkSize.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabelSoftdrinkSize.setText("-");

        jLabel19.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel19.setText("Total Price  :");

        jLabelTotalPrice.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabelTotalPrice.setText("-");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setText("Amount      :");

        jLabelmovie.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabelmovie.setText("-");

        jLabelamount.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabelamount.setText("-");

        jLabelticket.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabelticket.setText("-");

        jLabeltheater.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabeltheater.setText("-");

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel11.setText("Theater       :");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setText("No Ticket    :");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel5.setText("Movie Title :");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel6.setText("Snack          :");

        jLabelPopcornQuantity.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabelPopcornQuantity.setText("-");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel7.setText("Popcorn");

        jLabelPopcornSize.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabelPopcornSize.setText("-");

        jLabelSoftdrinkQuantity.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabelSoftdrinkQuantity.setText("-");

        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton1.setText("Home");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jButton1)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addGap(18, 18, 18)
                        .addComponent(jLabelTotalPrice))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabelSoftdrinkQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addGap(18, 18, 18)
                                .addComponent(jLabelPopcornQuantity, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel12))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelSoftdrinkSize)
                            .addComponent(jLabelPopcornSize)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel11))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabelmovie)
                            .addComponent(jLabelamount)
                            .addComponent(jLabeltheater)
                            .addComponent(jLabelticket)))
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addContainerGap(80, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(jButton1)))
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelticket)
                    .addComponent(jLabel3))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabeltheater)
                    .addComponent(jLabel11))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabelmovie))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jLabelamount))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(jLabelPopcornQuantity)
                    .addComponent(jLabel7)
                    .addComponent(jLabelPopcornSize))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelSoftdrinkQuantity)
                    .addComponent(jLabel12)
                    .addComponent(jLabelSoftdrinkSize))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(jLabelTotalPrice))
                .addContainerGap(33, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // Close the current receipt page
        this.setVisible(false);

        // Open the moviepage
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new moviepage().setVisible(true); // Assuming moviepage is the class for your movie page
            }
        });
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(receiptpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(receiptpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(receiptpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(receiptpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new receiptpage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabelPopcornQuantity;
    private javax.swing.JLabel jLabelPopcornSize;
    private javax.swing.JLabel jLabelSoftdrinkQuantity;
    private javax.swing.JLabel jLabelSoftdrinkSize;
    private javax.swing.JLabel jLabelTotalPrice;
    private javax.swing.JLabel jLabelamount;
    private javax.swing.JLabel jLabelmovie;
    private javax.swing.JLabel jLabeltheater;
    private javax.swing.JLabel jLabelticket;
    // End of variables declaration//GEN-END:variables
}
